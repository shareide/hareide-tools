# HareideART Tools

Private toolbox for [svein-hareide.com](https://svein-hareide.com) — built with HTML/JS and Claude API.

## Tools

| Tool | Description | Status |
|---|---|---|
| [SEO Auditor](./seo-auditor.html) | Analyse Shopify product CSV for SEO issues | ✅ Live |
| [SEO Auto-Fixer](./seo-autofixer.html) | Auto-generate SEO text for Shopify products via Claude API | ✅ Live |
| [Art Pin Generator](./art-pin-generator.html) | Generate Pinterest pins for artwork | 🔜 Coming |
| [Portrait Pin Generator](./portrait-pin-generator.html) | Generate Pinterest pins for Etsy portraits | 🔜 Coming |
| [Blog Topic Generator](./blog-topic-generator.html) | Generate SEO blog topics linked to Shopify products | 🔜 Coming |

## Usage

All tools run directly in the browser. No backend required.  
Tools using the Claude API require an Anthropic API key (entered in the tool itself — never stored in code).

## Security

⚠️ Never commit API keys to this repository.  
API keys are entered at runtime in each tool and are never saved to disk.

## Deploy

Hosted via GitHub Pages at:  
`https://shareide.github.io/hareide-tools/`
